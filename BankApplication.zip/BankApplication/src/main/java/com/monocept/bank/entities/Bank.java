package com.monocept.bank.entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.Data;

@Entity
@Data
public class Bank {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long bankId;
	String bankName;
	String abbriviation;
	
	@OneToMany(mappedBy = "bank")
	@JsonManagedReference
	private List<Account> accounts;
}
