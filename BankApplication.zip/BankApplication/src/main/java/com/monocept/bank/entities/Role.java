package com.monocept.bank.entities;

public enum Role {
	USER,
	ADMIN
}
