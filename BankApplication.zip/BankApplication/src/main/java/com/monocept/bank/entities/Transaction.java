package com.monocept.bank.entities;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.Data;

@Entity
@Data
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long tID;
	private Float amount;
    @CreationTimestamp
    private LocalDateTime createdOn;
	@Enumerated(EnumType.STRING)
	private TransactionType transactionType;
	
  	@ManyToOne(cascade = CascadeType.ALL)	
  	@JoinColumn(name = "senderAccID", referencedColumnName="accountNo")
  	@JsonBackReference
  	private Account account;
  	
  	@ManyToOne(cascade = CascadeType.ALL)	
  	@JoinColumn(name = "reciverAccId", referencedColumnName="accountNo")
  	@JsonBackReference
  	private Account reciver;
  	
  	String status;
	
}
