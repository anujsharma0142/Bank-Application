package com.monocept.bank.entities;

public enum TransactionType {
	WITHDRAW,
	DEPOSIT,
	TRANSFER
}
