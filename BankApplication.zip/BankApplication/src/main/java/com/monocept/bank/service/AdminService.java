package com.monocept.bank.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.monocept.bank.dto.request.AccountRequest;
import com.monocept.bank.dto.request.CreateBank;
import com.monocept.bank.dto.request.RegisterRequest;
import com.monocept.bank.dto.response.TransactionDetail;


public interface AdminService {
	
	ResponseEntity<String> registerUser(RegisterRequest request);
	
	ResponseEntity<String> createAcc(AccountRequest request);
	
	ResponseEntity<String> createBank(CreateBank request);
	
	List<TransactionDetail> getAllTransactions();
	
	ResponseEntity<?> registerAdmin(RegisterRequest request);
}
