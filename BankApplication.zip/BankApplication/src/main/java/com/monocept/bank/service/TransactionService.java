package com.monocept.bank.service;

import org.springframework.http.ResponseEntity;

import com.monocept.bank.dto.request.TransactionRequest;
import com.monocept.bank.dto.request.TransferRequest;

public interface TransactionService {
    ResponseEntity<String> deposit(TransactionRequest transactionRequest);
    ResponseEntity<String> withdraw(TransactionRequest transactionRequest);
    ResponseEntity<String> transfer(TransferRequest transferRequest);
    
}
