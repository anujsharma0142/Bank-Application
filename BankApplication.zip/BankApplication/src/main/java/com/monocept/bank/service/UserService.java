package com.monocept.bank.service;

import com.monocept.bank.dto.response.UserDetail;

public interface UserService {
	UserDetail getUserDetail(String email);
}
