package com.monocept.bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankApplication {

	@Test
	void contextLoads() {
		return;
	}

}
